package bean;

import java.util.List;

public class To {
    public To() {
    }

    public String name;
    public String parent;
    public List<To> children;
}
