package bean;

import java.util.List;

public class City {
    public City() {
    }

    public String name;
    public List<String> area;
}
