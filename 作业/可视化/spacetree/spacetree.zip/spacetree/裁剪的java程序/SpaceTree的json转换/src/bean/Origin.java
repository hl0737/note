package bean;

import java.util.List;

public class Origin {
    public Origin() {
    }

    public String name;
    public List<City> city;
}
